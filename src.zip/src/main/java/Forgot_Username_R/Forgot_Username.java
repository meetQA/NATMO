package Forgot_Username_R;

public class Forgot_Username {
	public static final String txt_Email = "//input[@name=\"email_address\"]";
	public static final String btn_Email_Request_Username = "//input[@value=\"Request Username\"]";
	public static final String btn_forgot_password = "//a[text()=\" Forgot Password\"]";
	public static final String label_validation_email = "//li[text()=\"Invalid email address\"]";
}
