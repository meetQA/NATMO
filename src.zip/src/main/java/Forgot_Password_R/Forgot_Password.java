package Forgot_Password_R;

public class Forgot_Password {
	public static final String txt_Username = "//input[@id=\"edit-name\"]";
	public static final String btn_Email_new_Password = "//input[@value=\"E-mail new password\"]";
	public static final String btn_Sign_In = "//a[text()=\" Sign In\"]";
	public static final String label_validation_email = "//li[text()=\"Username or e-mail address field is required.\"]";
	public static final String label_captcha = "//li[text()=\"Math question field is required.\"]";
}
